package towerdefense.livrables ;

import towerdefense.boards.ClassicalBoard ;


/**
 * Deliverable 1a is intended to demonstrate the functionalities of the
 * {@code ClassicalBoard} and the random generation of a single path.
 */
public class Livrable1a{

    /**
     * Private constructor to prevent instantiation.
     */
    private Livrable1a() {
    }

    /**
     * Main method used to demonstrate the functionalities of the ClassicalBoard
     * @param args It takes a maximum of two arguments to create a board (if only one is provided, a square board will be created).
     */
    public static void main(String[] args){


        if( args.length == 0 || args.length > 2){
            System.out.println("error, you must enter one or two parameters");
            return ;
        }

        else if (args.length == 1){

            int colRow ; 

            try{
                colRow = Integer.parseInt(args[0]) ;
                if(colRow <= 0 ){
                System.out.println("error, you must enter a positive number ");
                return ;
                }
            }
            catch(NumberFormatException  e){
                System.out.println("error, an integer number needed ");
                return ;
            }


            ClassicalBoard board = new ClassicalBoard(colRow, colRow); 
            System.out.println("A Textual Representation of the Board :");
            System.out.println(board.getTextualRepresentation());
            System.out.println("A Graphical Representation of the Board : ");
            board.display() ; 
        }

        else if (args.length == 2){
            int col ; 
            int row ;
            try{
                col = Integer.parseInt(args[0]) ;
                row = Integer.parseInt(args[1]) ;
                if( row <=0 || col<= 0 ){
                    System.out.println("error, two positve integer number needed");
                    return;
                }
            } 
            catch(NumberFormatException e){
                System.out.println("error, you must provide integer numbers");
                return;
            }
            ClassicalBoard board = new ClassicalBoard(row, col);
            System.out.println("A Textual Representation of the Board :");
            System.out.println(board.getTextualRepresentation());
            System.out.println("A Graphical Representation of the Board : ");
            board.display() ; 

        }

    }
    
}