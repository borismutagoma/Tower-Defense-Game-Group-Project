package towerdefense.livrables;

import towerdefense.BloonTowerDefenseGame;
import towerdefense.boards.ClassicalBoard;
import towerdefense.towers.tools.generator.RandomTowerGenerator;

/**
 * Main class for the Livrable 4a demonstration.
 * This class executes the specific scenarios required for the 4a milestone.
 */
public class Livrable4a {

    /**
    * Private constructor to prevent instantiation of this utility class.
    */
    private Livrable4a() {

    }

    /**
    * Entry point for the Livrable 4a execution.
    * @param args command line arguments
    */
    public static void main(String[] args) {

        if (args.length < 3) {
            System.out.println("Usage: java Livrable4a <rows> <columns> <nbBalloons>");
            return;
        }

        int CURRENT_NB_TOWERS = 7 * 2; // For delivreable 3 and 4
        int cols = Integer.parseInt(args[0]);
        int rows = Integer.parseInt(args[1]);
        int nb = Integer.parseInt(args[2]);

        // Generate the board
        ClassicalBoard board = new ClassicalBoard(rows, cols);

        // If there are not enough cells to place all the towers and the path, display an error.
        if((rows * cols) <= CURRENT_NB_TOWERS + board.getNumberOfPathsCells()){ 
            System.out.println("There are not enough cells to place all the towers and the path \nPlease increase the size of the board");
            return;
        }
         
        // Generate the game
        BloonTowerDefenseGame game = new BloonTowerDefenseGame(board, true, nb);

        // Generate all towers, two times
        RandomTowerGenerator randomTowerGenerator = new RandomTowerGenerator(board);
        randomTowerGenerator.towerGeneration();

        System.out.println("--- Starting Livrable 4a Simulation ---");
        game.play();
        System.out.println("\n --- Livrable 4a Simulation Finished ---");
    }
}
