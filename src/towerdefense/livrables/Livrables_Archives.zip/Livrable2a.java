package towerdefense.livrables ;

import towerdefense.BloonTowerDefenseGame ;
import towerdefense.boards.ClassicalBoard ;



/**
 * Deliverable 1a is intended to demonstrate the functionalities of the
 * {@code ClassicalBoard} and the random generation of a single path.
 */
public class Livrable2a{

    /**
     * Private constructor to prevent instantiation.
     */
    private Livrable2a() {
    }

    /**
     * Main method used to demonstrate the functionalities of the ClassicalBoard
     * @param args It takes a maximum of two arguments to create a board (if only one is provided, a square board will be created).
     */
    public static void main(String[] args){


        if( args.length == 0 || args.length > 3){
            System.out.println("error, you must enter atleast one to three parameter");
            return ;
        }

        else if (args.length == 1){

            int colRowBalloon ; 

            try{
                colRowBalloon = Integer.parseInt(args[0]) ;
                if(colRowBalloon <= 0 ){
                    System.out.println("error, you must enter a positive number ");
                    return ;
                }
            }
            catch(NumberFormatException  e){
                System.out.println("error, an integer number needed ");
                return ;
            }

            ClassicalBoard board = new ClassicalBoard(colRowBalloon, colRowBalloon); 
            BloonTowerDefenseGame game = new BloonTowerDefenseGame(board, true, colRowBalloon) ;
            game.play();

        }

        else if (args.length == 2){
            int col ; 
            int rowBalloon ;
            try{
                col = Integer.parseInt(args[0]) ;
                rowBalloon = Integer.parseInt(args[1]) ;
                if( rowBalloon <=0 || col<= 0 ){
                    System.out.println("error, two positve integer number needed");
                    return ;
                }
            } 
            catch(NumberFormatException e){
                System.out.println("error, you must provide integer numbers");
                return;
            }
            ClassicalBoard board = new ClassicalBoard(rowBalloon, col);
            BloonTowerDefenseGame game = new BloonTowerDefenseGame(board, true, rowBalloon) ;
            game.play();

        }


        else if (args.length == 3){
            int col ; 
            int row ;
            int nbBalloons ; 
            try{
                col = Integer.parseInt(args[0]) ;
                row = Integer.parseInt(args[1]) ;
                nbBalloons = Integer.parseInt(args[2]) ;
                if( col <=0 || row<= 0 || nbBalloons <= 0 ){
                    System.out.println("error, positive integers numbers needed");
                    return;
                }
            } 
            catch(NumberFormatException e){
                System.out.println("error, you must provide integer numbers");
                return;
            }    
            
            ClassicalBoard board = new ClassicalBoard(row, col);
            BloonTowerDefenseGame game = new BloonTowerDefenseGame(board, true, nbBalloons) ;
            game.play();

        }

    }
    
}