package towerdefense.livrables ;

import towerdefense.boards.RandomBoard ;



/**
 * Deliverable 1b is intended to demonstrate the functionalities of the
 * {@code RandomBoard} and the random generation of one or more paths.
 */
public class Livrable1b{

    /**
     * Private constructor to prevent instantiation.
     */
    private Livrable1b() {
    }

    /**
     * Main method used to demonstrate the functionalities of the RandomBoard
     * @param args It takes a maximum of three arguments to create a board
     *             For more information, see the ReadMe file.
     */
    public static void main(String[] args){



        if( args.length == 0 || args.length > 3){
            System.out.println("error, you must provide atleast one parameter, maximum three ");
            return ;
        }

        else if (args.length == 1){

            int colRowPath ;  

            try{
                colRowPath = Integer.parseInt(args[0]) ;
                if(colRowPath <= 0 || colRowPath > colRowPath*4){
                System.out.println("error, you must enter a positive number or a valid number of paths ");
                return ;
                }
            }
            catch(NumberFormatException  e){
                System.out.println("error, an integer number needed ");
                return ;
            }


            RandomBoard board = new RandomBoard(colRowPath, colRowPath, colRowPath); 
            System.out.println("A Textual Representation of the Board :");
            System.out.println(board.getTextualRepresentation());
            System.out.println("A Graphical Representation of the Board : ");
            board.display() ; 
        }


        else if (args.length == 2){

            int colRow ;
            int path ;  

            try{
                colRow = Integer.parseInt(args[0]) ;
                path = Integer.parseInt(args[1]) ;
                if(colRow <= 0 || path <= 0 || path > colRow*4){
                System.out.println("error, you must enter a positive number or a valid number of paths ");
                return ;
                }
            }
            catch(NumberFormatException  e){
                System.out.println("error, an integer number needed ");
                return ;
            }


            RandomBoard board = new RandomBoard(colRow, colRow, path); 
            System.out.println("A Textual Representation of the Board :");
            System.out.println(board.getTextualRepresentation());
            System.out.println("A Graphical Representation of the Board : ");
            board.display() ; 
        }

        else if (args.length == 3){
            int col ; 
            int row ;
            int path ; 
            try{
                col = Integer.parseInt(args[0]) ;
                row = Integer.parseInt(args[1]) ;
                path = Integer.parseInt(args[2]) ;
                if( col <=0 || row<= 0 || path <= 0 || path > (col*row+4) ){
                    System.out.println("error, positive integer number needed or a valid path number");
                    return;
                }
            } 
            catch(NumberFormatException e){
                System.out.println("error, you must provide integer numbers");
                return;
            }    

            RandomBoard board = new RandomBoard(row, col, path);
            System.out.println("A Textual Representation of the Board :");
            System.out.println(board.getTextualRepresentation());
            System.out.println("A Graphical Representation of the Board : ");
            board.display() ; 

        }

    }
    
}