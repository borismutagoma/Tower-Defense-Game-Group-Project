package towerdefense.livrables;

import towerdefense.BloonTowerDefenseGame;
import towerdefense.boards.RandomBoard;
import towerdefense.towers.tools.generator.RandomTowerGenerator;

public class Livrable4b {
    
    /**
     * Private constructor to prevent instantiation.
     */
    private Livrable4b() {
    }

    /**
    * Entry point for the Livrable 4b execution.
    * @param args command line arguments
    */
    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: java Livrable4b <rows> <columns> <nbPaths>");
            return;
        }

        int CURRENT_NB_TOWERS = 7 * 2; // For delivreable 3 and 4
        int cols = Integer.parseInt(args[0]);
        int rows = Integer.parseInt(args[1]);
        int nbPaths = Integer.parseInt(args[2]);

        // Generate the board
        RandomBoard board = new RandomBoard(rows, cols, nbPaths); 

        // If there are not enough cells to place all the towers and the path, display an error.
        if((rows * cols) <= CURRENT_NB_TOWERS + board.getNumberOfPathsCells()){ 
            System.out.println("There are not enough cells to place all the towers and the path \nPlease increase the size of the board");
            return;
        }
         
        // Generate the game
        BloonTowerDefenseGame game = new BloonTowerDefenseGame(board, true, nbPaths); // As many paths as balloons

        // Generate all towers, two times
        RandomTowerGenerator randomTowerGenerator = new RandomTowerGenerator(board);
        randomTowerGenerator.towerGeneration();

        System.out.println("--- Starting Livrable 4b (Multi-Path) ---");
        game.play();
        System.out.println("\n --- Livrable 4b Simulation Finished ---");
    }
}
